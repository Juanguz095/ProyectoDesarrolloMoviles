package com.auditlab.control

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.auditlab.common.*
import com.auditlab.design.*
import kotlinx.coroutines.CoroutineScope

class ControlViewModel(application: android.app.Application) : androidx.lifecycle.AndroidViewModel(application) {
    val session = ControlSession(application)
    val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Main.immediate)
    var pendingExport: ControlSession.ExportTicket? = null
    override fun onCleared() { scope.coroutineContext[kotlinx.coroutines.Job]?.cancel() }
}
class MainActivity : ComponentActivity() {
    private val model by lazy { androidx.lifecycle.ViewModelProvider(this)[ControlViewModel::class.java] }
    private val saveCsv = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val ticket = model.pendingExport; model.pendingExport = null
        if (uri == null || ticket == null) model.session.notifyExportCancelled()
        else if (!ExportDestination.isAllowed(uri)) model.session.notifyExportUnavailable()
        else model.session.export(ticket, model.scope, uri) { bytes ->
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes); it.flush() }
                ?: error("No se pudo abrir el documento")
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(0xFFDAD7C0.toInt(), 0xFFDAD7C0.toInt()),
            navigationBarStyle = SystemBarStyle.light(0xFFDAD7C0.toInt(), 0xFFDAD7C0.toInt()),
        )
        setContent { AuditTheme { Surface(modifier = Modifier.fillMaxSize()) {
            ControlScreen(model.session, onExport = {
                model.session.exportTicket()?.let { ticket ->
                    model.pendingExport = ticket
                    try { saveCsv.launch("AuditLab-eventos.csv") }
                    catch (_: android.content.ActivityNotFoundException) {
                        model.pendingExport = null
                        model.session.notifyExportUnavailable()
                    } catch (_: SecurityException) {
                        model.pendingExport = null
                        model.session.notifyExportUnavailable()
                    }
                }
            }, workScope = model.scope, onOpenReport = {
                model.session.lastReportUri?.let { uri ->
                    try { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW)
                        .setDataAndType(uri, "text/csv").addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                    catch (_: android.content.ActivityNotFoundException) { model.session.notifyViewerUnavailable() }
                    catch (_: SecurityException) { model.session.notifyViewerUnavailable() }
                }
            })
        } } }
    }
}

@Composable
internal fun ControlScreen(session: ControlSession, onExport: (() -> Unit)? = null,
    workScope: CoroutineScope? = null, onOpenReport: (() -> Unit)? = null) {
    val composeScope = rememberCoroutineScope()
    val scope = workScope ?: composeScope
    var screen by rememberSaveable { mutableStateOf("inicio") }
    var chosenDevice by rememberSaveable { mutableStateOf<String?>(null) }
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val currentDevice = session.devices.firstOrNull { it.deviceId == chosenDevice } ?: session.devices.firstOrNull()
    LaunchedEffect(session.signedIn) {
        if (session.signedIn) {
            password = ""; user = ""
            if (!session.devicesLoaded && !session.busy) session.refresh(scope)
        } else { screen = "inicio"; chosenDevice = null }
    }
    LaunchedEffect(screen, currentDevice?.deviceId, session.overviewDevice, session.busy, session.signedIn) {
        if (screen == "inicio" && session.signedIn && !session.busy && currentDevice != null && session.overviewDevice != currentDevice.deviceId)
            session.loadOverview(currentDevice.deviceId, scope)
    }
    BackHandler(session.signedIn && screen != "inicio") {
        screen = when (screen) { "whatsapp" -> "dispositivo"; "dispositivo" -> "dispositivos"; "auditoria", "inscripcion" -> "mas"; else -> "inicio" }
    }
    if (session.logoutConfirmation && session.signedIn) AlertDialog(onDismissRequest = session::cancelLogout,
        title = { Text("Cerrar sesión", style = MaterialTheme.typography.titleLarge) },
        text = { Text("Se eliminará la sesión local de este centro de control.") },
        confirmButton = { AuditLink("Confirmar salida", { session.cancelLogout(); session.logout(scope) }) },
        dismissButton = { AuditLink("Cancelar", session::cancelLogout) })
    session.revokeTarget?.takeIf { session.isAdmin }?.let { target ->
        AlertDialog(onDismissRequest = session::cancelRevoke,
            title = { Text("Revocar dispositivo", style = MaterialTheme.typography.titleLarge) },
            text = { Text("Se bloquearán nuevas transmisiones de $target. El agente detendrá la captura al recibir la revocación del servidor. Volver a inscribirlo requiere consentimiento y código nuevos.") },
            confirmButton = { AuditLink("Confirmar revocación", { session.cancelRevoke(); session.revoke(target, scope) }) },
            dismissButton = { AuditLink("Cancelar", session::cancelRevoke) })
    }
    session.detail?.let { event -> EventDetail(event, session::closeDetail) }
    fun openEvents(device: String?) {
        if (session.busy) return
        session.applyFilters(EventQuery(device = device), scope); screen = "eventos"
    }
    val selectedTab = when (screen) { "whatsapp", "dispositivo" -> "dispositivos"; "inscripcion", "auditoria" -> "mas"; else -> screen }
    AuditPage(key = if (session.signedIn) screen else "login", feedback = session.message, working = session.busy, bottom = if (session.signedIn) ({
        ControlNavigation(selectedTab, !session.busy) { next ->
            screen = next
            if (next == "eventos" && !session.eventsLoaded) session.applyFilters(session.query, scope)
        }
    }) else null) {
        if (!session.signedIn) {
            AuditHeader("AUDITLAB", "CENTRO DE CONTROL")
            Spacer(Modifier.height(10.dp))
            Text("INICIAR SESIÓN", style = MaterialTheme.typography.titleLarge)
            Text("Consulta los dispositivos y eventos autorizados de tu grupo.", color = AuditColors.Muted)
            AuditField("URL del servicio", session.serverUrl, session::updateServerUrl, !session.busy && !session.storageBlocked,
                placeholder = "https://tu-servidor")
            AuditField("Usuario", user, { user = it }, !session.busy)
            AuditField("Contraseña", password, { password = it }, !session.busy, secret = true)
            AuditButton(if (session.busy) "Conectando…" else "Iniciar sesión", { session.login(user.trim(), password, scope) },
                !session.busy && !session.storageBlocked && user.isNotBlank() && password.isNotEmpty())
            if (session.storageBlocked) AuditButton("Borrar sesión local", { session.clearLocal(scope) }, !session.busy, outlined = true)
            Text("Acceso por rol: administrador o auditor. Todas las consultas quedan registradas.", color = AuditColors.Muted)
        } else {
            when (screen) {
                "inicio" -> Dashboard(session, currentDevice, scope, onEvents = { openEvents(currentDevice?.deviceId) })
                "eventos" -> EventExplorer(session, scope, onExport, onOpenReport)
                "whatsapp" -> WhatsAppPreviewsView(session,currentDevice?.deviceId) { screen="dispositivo" }
                "dispositivos" -> DeviceList(session, scope) { id -> chosenDevice = id; screen = "dispositivo" }
                "dispositivo" -> {
                    DeviceDetail(session, currentDevice, scope, onBack = { screen = "dispositivos" },
                        onEvents = { openEvents(currentDevice?.deviceId) },
                        onAudit = { session.loadAudit(scope); screen = "auditoria" }, onWhatsApp = { screen="whatsapp" })
                }
                "auditoria" -> AuditHistory(session, scope) { screen = "mas" }
                "inscripcion" -> EnrollmentView(session, scope) { screen = "mas" }
                else -> {
                    AuditHeader("MÁS", "CUENTA Y ADMINISTRACIÓN")
                    AuditPanel {
                        Text(session.username, style = MaterialTheme.typography.titleMedium)
                        Text("Rol: ${if (session.isAdmin) "administrador" else "auditor"}")
                        Text(session.serverUrl, color = AuditColors.Muted)
                    }
                    AuditButton("Consultar auditoría", { session.loadAudit(scope); screen = "auditoria" }, !session.busy)
                    if (session.isAdmin) AuditButton("Crear código de inscripción", { screen = "inscripcion" }, !session.busy)
                    AuditButton("Actualizar dispositivos", { session.refresh(scope) }, !session.busy, outlined = true)
                    AuditRule()
                    Text("Última actualización de la lista", color = AuditColors.Muted)
                    Text(displayTime(session.devicesUpdatedAt))
                    AuditButton("Cerrar sesión", session::requestLogout, !session.busy, outlined = true)
                }
            }
        }
    }
}

@Composable
private fun ControlNavigation(selected: String, enabled: Boolean, onSelect: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp)) {
        AuditRule()
        Row(Modifier.fillMaxWidth()) {
            listOf("inicio" to "INICIO", "eventos" to "EVENTOS", "dispositivos" to "EQUIPOS", "mas" to "MÁS").forEach { (id, label) ->
                TextButton({ onSelect(id) }, Modifier.weight(1f).heightIn(min = 52.dp), enabled = enabled,
                    shape = androidx.compose.ui.graphics.RectangleShape,
                    colors = ButtonDefaults.textButtonColors(containerColor = if (selected == id) AuditColors.Panel else androidx.compose.ui.graphics.Color.Transparent),
                    contentPadding = PaddingValues(2.dp)) {
                    Text(label, style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (selected == id) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun EventDetail(event: AuditEvent, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose,
        title = { Text("DETALLE DE EVENTO", style = MaterialTheme.typography.titleLarge) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(eventTitle(event), style = MaterialTheme.typography.titleMedium)
            Text(if (event.isSimulated) "Evento simulado" else "Evento real del dispositivo")
            AuditRule()
            SectionLabel("Fecha del evento"); Text(displayTime(event.timestamp))
            SectionLabel("Recibido por el servidor"); Text(displayTime(event.receivedAt))
            SectionLabel("Dispositivo"); Text(event.sourceDevice)
            SectionLabel("Identificador del evento"); Text(event.eventId)
            metadataDescription(event.metadata).takeIf { it.isNotEmpty() }?.let { Text(it) }
            Text("Código: ${event.metadata["appEventCode"] ?: "Sin código"}")
            Text("Categoría: ${categoryName(event.category)}")
            Text("Dirección: ${when (event.direction) { "inbound" -> "Entrante"; "outbound" -> "Saliente"; else -> "Ocurrido" }}")
            AuditRule()
            SectionLabel("Consentimiento"); Text(event.consent.consentId)
            Text("Política: ${event.consent.policyVersion}")
            Text("Aceptado: ${displayTime(event.consent.acceptedAt)}")
        } }, confirmButton = { AuditLink("Cerrar detalle", onClose) })
}

internal fun eventTitle(event: AuditEvent): String = metadataTitle(event.metadata, categoryName(event.category))

internal fun categoryName(category: String): String = when (category) {
    "device_status" -> "Batería y conexión"
    "sms" -> "SMS"
    "call" -> "Llamadas"
    "app_lifecycle" -> "Actividad de la app"
    "sync" -> "Sincronización"
    else -> category
}
