# AuditLab - servidor Windows por USB

Este ZIP contiene el servidor, el asistente PowerShell y el codigo fuente.
Las dos APKs se descargan por separado y se guardan en la carpeta apks.
Extrae todo en C:\AuditLab y sigue PASOS-WINDOWS.md.
El asistente Windows no se ha ejecutado en Windows desde este entorno Linux.
