# AuditLab 0.3.0-rc1 — Servidor Windows

Lee PASOS-WINDOWS.md. Necesitas Docker Desktop y Java 21. Extrae completo en C:\AuditLab.
Descarga por separado auditlab-agent-0.3.0-rc1.apk y auditlab-control-0.3.0-rc1.apk.

Si actualizas: detén el servidor y conserva C:\AuditLab\.auditlab-windows. Renombra api
a api-respaldo-0.2 antes de extraer api nueva en la misma ruta. No borres la base ni volúmenes.
El lanzador aplica V3 conservando los datos y la contraseña existente.

Ejecuta en PowerShell:
    powershell -NoProfile -ExecutionPolicy Bypass -File .\Iniciar-AuditLab.ps1

Comprueba en la PC http://127.0.0.1:8081/ready. La raíz / no es una página web.
Usuario del Centro: admin. Contraseña: la elegida al iniciar Windows por primera vez.
Ambos teléfonos requieren adb reverse y la URL http://127.0.0.1:8081.

El Agente pide autorización adicional y permisos para metadatos de SMS/llamadas reales.
No consulta cuerpos, números, contactos ni audio. Android puede restringir los permisos.
La prueba nativa aprobada usa módem/apps del emulador API28, no teléfonos ni Windows.
Firma debug de desarrollo; no es distribución firmada por el responsable ni piloto público.
Fuente incluida: 9bc2ca92a6b4f84b6e615ac4601165060f31e628. Sin contraseñas, claves privadas ni bases de datos.
